---
name: backtest-workbench-v011
description: 基于用户授权文件完成可复算的本地策略回测，保留来源、未知项与版本。
---
## 目标
真实计算、文件交付与基于证据的研究说明。
## 输入
显式来源、日期、单位及方法参数。详见 references/input-protocol.md；examples 仅合成验收，不能代替用户资料。
## 工作流
核对范围和依赖→输入与来源→本地程序→独立复算→研究稿→实际文件/界面检查→更新另存（使用 --previous-input 并保留程序生成的change-note.md）。
## 工具
Python3.10+标准库，已有普通文件/命令权限；可选当前已选合格金融连接器；没有自动安装或直接HTTP。
## 输出
input/summary/decisions JSON、equity/trades/fills CSV、交互 HTML、口径说明与复算代码。外部时效/账号、未实现高级能力分别披露。
## 禁止行为
补造事实、缺值补零、无证据评级、覆盖旧版、写安装包或数据库、强杀、攻击注入、凭据读取、执行未经审校的 WorkBuddy 上游程序。本易界包 scripts/backtest.py 是已审校计算器，可按输入协议正常执行。
## 审批要求
沿当前会话与现有逐次连接器审批；本地输入文件不是联网或交易许可。
## 评测标准
真实文件、正确计算、源输入可回溯、普通边界、打开和交互检查；详见 checklists/quality-checklist.md。
